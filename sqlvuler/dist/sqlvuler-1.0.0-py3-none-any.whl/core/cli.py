#!/usr/bin/env python3
"""
Command Line Interface for SQLVuler
Provides an interactive terminal-like interface for the tool
"""

import os
import sys
import cmd
import readline
import shlex
from datetime import datetime

from colorama import Fore, Style, init

from sqlvuler.core.config import ConfigManager
from sqlvuler.utils.logger import get_logger

# Initialize colorama for cross-platform colored terminal output
init()

class CLIManager(cmd.Cmd):
    """Interactive CLI for SQLVuler"""
    
    intro = ""
    prompt = f"{Fore.CYAN}sqlvuler> {Style.RESET_ALL}"
    doc_header = "Available commands (type help <command>):"
    ruler = "="
    
    def __init__(self, config_manager=None, show_banner=True):
        """
        Initialize the CLI Manager
        
        Args:
            config_manager (ConfigManager): Configuration manager instance
            show_banner (bool): Whether to show the banner on startup
        """
        super().__init__()
        self.logger = get_logger()
        self.config_manager = config_manager or ConfigManager()
        self.current_module = None
        self.current_target = None
        self.scan_history = []
        self.last_command = None
        
        # Setup command history
        self.history_file = os.path.expanduser("~/.sqlvuler_history")
        
        # Display banner if requested
        if show_banner:
            self._print_banner()
    
    def _print_banner(self):
        """Display the SQLVuler banner"""
        banner = f"""
{Fore.RED}
 ____   ___  _     __     __        _           
/ ___| / _ \| |    \ \   / /   _   | | ___ _ __ 
\___ \| | | | |     \ \ / / | | |  | |/ _ \ '__|
 ___) | |_| | |___   \ V /| |_| |  | |  __/ |   
|____/ \__\_\_____|   \_/  \__,_|  |_|\___|_|   
                                                
{Style.RESET_ALL}
{Fore.YELLOW}Version: 1.0.0{Style.RESET_ALL}
{Fore.YELLOW}Author: Educational Purpose Tool{Style.RESET_ALL}

{Fore.RED}DISCLAIMER: EDUCATIONAL PURPOSE ONLY{Style.RESET_ALL}
This tool is designed for educational purposes only.
Use only on systems you have permission to test.
Unauthorized scanning of websites or applications is illegal.
The author is not responsible for any misuse of this tool.

Type {Fore.GREEN}'help'{Style.RESET_ALL} to see available commands.
Type {Fore.GREEN}'exit'{Style.RESET_ALL} to exit.
"""
        print(banner)
    
    def start(self):
        """Start the interactive CLI"""
        # Try to load command history
        self._load_history()
        
        # Start the command loop
        try:
            self.cmdloop()
        finally:
            # Save command history when exiting
            self._save_history()
    
    def _load_history(self):
        """Load command history from file"""
        try:
            if os.path.exists(self.history_file):
                readline.read_history_file(self.history_file)
                self.logger.debug(f"Loaded command history from {self.history_file}")
        except Exception as e:
            self.logger.debug(f"Could not load command history: {str(e)}")
    
    def _save_history(self):
        """Save command history to file"""
        try:
            readline.write_history_file(self.history_file)
            self.logger.debug(f"Saved command history to {self.history_file}")
        except Exception as e:
            self.logger.debug(f"Could not save command history: {str(e)}")
    
    def emptyline(self):
        """Handle empty line (do nothing)"""
        pass
    
    def default(self, line):
        """Handle unknown commands"""
        self.logger.error(f"Unknown command: {line}")
        print(f"Type {Fore.GREEN}'help'{Style.RESET_ALL} to see available commands.")
    
    def completedefault(self, text, line, begidx, endidx):
        """Default tab completion"""
        return []
    
    def do_exit(self, arg):
        """Exit the application"""
        print(f"\n{Fore.YELLOW}Exiting SQLVuler. Goodbye!{Style.RESET_ALL}")
        return True
    
    def do_quit(self, arg):
        """Exit the application (alias for exit)"""
        return self.do_exit(arg)
    
    def do_EOF(self, arg):
        """Handle Ctrl+D to exit"""
        print()  # Add a newline
        return self.do_exit(arg)
    
    def do_clear(self, arg):
        """Clear the screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def do_banner(self, arg):
        """Display the SQLVuler banner"""
        self._print_banner()
    
    def do_history(self, arg):
        """Display command history"""
        history_size = readline.get_current_history_length()
        for i in range(1, history_size + 1):
            cmd = readline.get_history_item(i)
            if cmd:
                print(f"{i}: {cmd}")
    
    def do_set(self, arg):
        """
        Set configuration options
        Usage: set <option> <value>
        """
        args = shlex.split(arg)
        if len(args) < 2:
            print(f"{Fore.RED}Error: Missing parameters{Style.RESET_ALL}")
            print(f"Usage: set <option> <value>")
            return
        
        option = args[0]
        value = args[1]
        
        # Handle special case for boolean values
        if value.lower() in ('true', 'yes', 'on', '1'):
            value = True
        elif value.lower() in ('false', 'no', 'off', '0'):
            value = False
        
        try:
            self.config_manager.set(option, value)
            print(f"{Fore.GREEN}Set {option} = {value}{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error setting option: {str(e)}{Style.RESET_ALL}")
    
    def do_get(self, arg):
        """
        Get configuration option value
        Usage: get <option>
        """
        args = shlex.split(arg)
        if not args:
            print(f"{Fore.RED}Error: Missing parameter{Style.RESET_ALL}")
            print(f"Usage: get <option>")
            return
        
        option = args[0]
        
        try:
            value = self.config_manager.get(option)
            print(f"{option} = {value}")
        except Exception as e:
            print(f"{Fore.RED}Error getting option: {str(e)}{Style.RESET_ALL}")
    
    def do_show(self, arg):
        """
        Show information about various components
        Usage: show [component]
        
        Components:
          config     - Show current configuration
          options    - Show available options
          modules    - Show available modules
          params     - Show detected parameters
          results    - Show scan results
        """
        args = shlex.split(arg)
        if not args:
            print(f"{Fore.RED}Error: Missing component{Style.RESET_ALL}")
            print(f"Usage: show <component>")
            print(f"Type 'help show' for more information.")
            return
        
        component = args[0].lower()
        
        if component == 'config':
            self._show_config()
        elif component == 'options':
            self._show_options()
        elif component == 'modules':
            self._show_modules()
        elif component == 'params':
            self._show_params()
        elif component == 'results':
            self._show_results()
        else:
            print(f"{Fore.RED}Unknown component: {component}{Style.RESET_ALL}")
            print(f"Type 'help show' for more information.")
    
    def _show_config(self):
        """Show current configuration"""
        config = self.config_manager.get_all()
        
        print(f"\n{Fore.GREEN}Current Configuration:{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
        
        for section, options in config.items():
            print(f"\n{Fore.CYAN}[{section}]{Style.RESET_ALL}")
            for option, value in options.items():
                print(f"  {option} = {value}")
        
        print(f"\n{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
    
    def _show_options(self):
        """Show available options"""
        print(f"\n{Fore.GREEN}Available Options:{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
        
        # We'll implement this when we have the options defined
        print(f"{Fore.YELLOW}Not implemented yet.{Style.RESET_ALL}")
        
        print(f"\n{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
    
    def _show_modules(self):
        """Show available modules"""
        print(f"\n{Fore.GREEN}Available Modules:{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
        
        # We'll implement this when we have modules defined
        print(f"{Fore.YELLOW}Not implemented yet.{Style.RESET_ALL}")
        
        print(f"\n{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
    
    def _show_params(self):
        """Show detected parameters"""
        if not self.current_target:
            print(f"{Fore.RED}No target URL set. Use 'scan <url>' first.{Style.RESET_ALL}")
            return
        
        print(f"\n{Fore.GREEN}Detected Parameters for {self.current_target}:{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
        
        # We'll implement parameter detection later
        print(f"{Fore.YELLOW}Not implemented yet.{Style.RESET_ALL}")
        
        print(f"\n{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
    
    def _show_results(self):
        """Show scan results"""
        if not self.scan_history:
            print(f"{Fore.RED}No scan results available.{Style.RESET_ALL}")
            return
        
        print(f"\n{Fore.GREEN}Scan Results:{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
        
        # We'll implement results display later
        print(f"{Fore.YELLOW}Not implemented yet.{Style.RESET_ALL}")
        
        print(f"\n{Fore.YELLOW}{'=' * 50}{Style.RESET_ALL}")
    
    def do_scan(self, arg):
        """
        Start a scan on the specified URL
        Usage: scan <url> [options]
        
        Options:
          -t, --threads <num>    Number of threads (default: 5)
          -d, --depth <num>      Scan depth (default: 1)
          -v, --verbose          Verbose output
        """
        args = shlex.split(arg)
        if not args:
            print(f"{Fore.RED}Error: Missing URL{Style.RESET_ALL}")
            print(f"Usage: scan <url> [options]")
            print(f"Type 'help scan' for more information.")
            return
        
        url = args[0]
        self.current_target = url
        
        # Parse options (to be implemented)
        # For now, just acknowledge the command
        
        print(f"\n{Fore.GREEN}Starting scan on {url}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}This functionality will be implemented in Phase 2.{Style.RESET_ALL}")
        
        # Add to scan history
        self.scan_history.append({
            'url': url,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'pending'
        })
    
    def do_use(self, arg):
        """
        Select a module to use
        Usage: use <module>
        """
        args = shlex.split(arg)
        if not args:
            print(f"{Fore.RED}Error: Missing module{Style.RESET_ALL}")
            print(f"Usage: use <module>")
            return
        
        module = args[0]
        
        # We'll implement module selection later
        print(f"\n{Fore.GREEN}Selected module: {module}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}This functionality will be implemented in Phase 2.{Style.RESET_ALL}")
        
        self.current_module = module
    
    def do_back(self, arg):
        """Return to the main menu from a module"""
        if not self.current_module:
            print(f"{Fore.YELLOW}Already at the main menu.{Style.RESET_ALL}")
            return
        
        self.current_module = None
        print(f"{Fore.GREEN}Returned to main menu.{Style.RESET_ALL}")
    
    def do_help(self, arg):
        """Show help information"""
        # Override the default help command
        super().do_help(arg)