# SQLVuler - SQL Injection Vulnerability Scanner

**DISCLAIMER: EDUCATIONAL PURPOSE ONLY**

This tool is designed for educational purposes only. Use only on systems you have permission to test. Unauthorized scanning of websites or applications is illegal. The author is not responsible for any misuse of this tool.

## Overview

SQLVuler is a comprehensive SQL injection vulnerability scanner with a terminal-like interface. It's designed to help security professionals and students learn about SQL injection vulnerabilities and how to detect them.

## Features

- Interactive command-line interface
- Modular and extensible architecture
- Customizable payload system
- Multiple detection techniques:
  - Error-based injection detection
  - Time-based injection detection
  - Boolean-based injection detection
- Database identification and fingerprinting
- Data extraction capabilities
- Comprehensive reporting

## Installation

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Steps

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/sqlvuler.git
   cd sqlvuler
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Install the package in development mode:
   ```
   pip install -e .
   ```

## Usage

### Basic Usage

```
python sqlvuler.py
```

This will start the interactive CLI where you can enter commands.

### Command-line Options

```
python sqlvuler.py -h
```

This will display help information and available command-line options.

### Interactive Commands

Once in the interactive CLI, you can use various commands:

- `scan <url>` - Start a scan on the specified URL
- `set <option> <value>` - Set configuration options
- `show <component>` - Display information (params, results, etc.)
- `use <module>` - Switch to a specific module
- `help` - Display help information
- `exit/quit` - Exit the program

## Project Structure

```
sqlvuler/
├── __init__.py
├── core/
│   ├── __init__.py
│   ├── cli.py              # Terminal-like interface
│   ├── scanner.py          # Main scanning engine
│   ├── payload_manager.py  # Handles payload loading and management
│   ├── report.py           # Report generation and management
│   └── config.py           # Configuration management
├── payloads/
│   ├── detection/          # SQL injection detection payloads
│   │   ├── error_based.txt
│   │   ├── time_based.txt
│   │   └── boolean_based.txt
│   ├── dbms/               # DBMS-specific payloads
│   │   ├── mysql/
│   │   │   ├── version.txt
│   │   │   ├── databases.txt
│   │   │   ├── tables.txt
│   │   │   └── columns.txt
│   │   ├── postgresql/
│   │   │   └── ...
│   │   ├── mssql/
│   │   │   └── ...
│   │   ├── oracle/
│   │   │   └── ...
│   │   └── sqlite/
│   │       └── ...
│   └── exploitation/       # Data extraction payloads
│       ├── dump_data.txt
│       └── ...
├── utils/
│   ├── __init__.py
│   ├── logger.py           # Logging utilities
│   ├── http.py             # HTTP request handling
│   └── helpers.py          # Helper functions
├── data/
│   └── configs/            # User configuration files
│       └── default.json
├── requirements.txt
└── sqlvuler.py             # Main entry point
```

## Development

### Setting Up Development Environment

1. Create a virtual environment:
   ```
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```

2. Install development dependencies:
   ```
   pip install -r requirements-dev.txt
   ```

3. Open the project in VS Code:
   ```
   code sqlvuler.code-workspace
   ```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- This tool is inspired by SQLmap and other open-source security tools
- Thanks to the security community for their continuous research on SQL injection vulnerabilities